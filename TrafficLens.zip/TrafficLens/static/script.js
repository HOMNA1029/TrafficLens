// === Network Information API ===
function updateNetworkStatus() {
  const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  const statusText = connection ? `Connection: ${connection.effectiveType}` : "Network info unavailable";
  document.getElementById("network-status").innerText = statusText;
}
updateNetworkStatus();
if (navigator.connection) {
  navigator.connection.addEventListener('change', updateNetworkStatus);
}


// === Canvas API ===
document.addEventListener("DOMContentLoaded", () => {
  const canvas = document.getElementById("safety-canvas");
  const ctx = canvas.getContext("2d");

  const select = document.getElementById("sign-select");
  const tipsContainer = document.querySelector(".tips");

  function drawSign(type) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (type === "stop") {
      ctx.fillStyle = "red";
      ctx.beginPath();
      ctx.arc(100, 75, 50, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "white";
      ctx.font = "20px Arial";
      ctx.fillText("STOP", 65, 85);
    } else if (type === "go") {
      ctx.fillStyle = "green";
      ctx.fillRect(60, 60, 80, 40);
      ctx.fillStyle = "white";
      ctx.font = "20px Arial";
      ctx.fillText("GO", 85, 85);
    } else if (type === "caution") {
      ctx.fillStyle = "yellow";
      ctx.beginPath();
      ctx.moveTo(100, 25);
      ctx.lineTo(175, 125);
      ctx.lineTo(25, 125);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "black";
      ctx.font = "18px Arial";
      ctx.fillText("!", 97, 95);
    }
  }

  const tipsMap = {
    stop: [
      "🛑 Always stop before crossing.",
      "👀 Look both ways.",
      "🚸 Ensure it's safe before moving."
    ],
    go: [
      "✅ Proceed only when it's green.",
      "🚶 Cross quickly and carefully.",
      "👣 Let others finish crossing first."
    ],
    caution: [
      "⚠️ Be alert near intersections.",
      "🚧 Watch for construction signs.",
      "👀 Make eye contact with drivers."
    ]
  };

  function updateTips() {
    const selectedOptions = Array.from(select.selectedOptions).map(opt => opt.value);
    const combinedTips = selectedOptions.flatMap(value => tipsMap[value] || []);
    tipsContainer.innerHTML = combinedTips
      .map(tip => `<div class="tip">${tip}</div>`)
      .join("");

    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
        }
      });
    }, { threshold: 0.3 });

    document.querySelectorAll(".tip").forEach(tip => observer.observe(tip));
  }

  select.addEventListener("change", () => {
    updateTips();
    drawSign(select.value); // <-- also draw the sign when user changes selection
  });

  // Initial state
  updateTips();
  drawSign(select.value);
});



// === Intersection Observer API ===
const tips = document.querySelectorAll(".tip");
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
    }
  });
}, { threshold: 0.3 });
tips.forEach((tip) => observer.observe(tip));


function logToServer(data) {
  fetch("/log", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data)
  }).then(res => res.json())
    .then(res => console.log("Logged:", res));
}

// Example use:
setInterval(() => {
  const conn = navigator.connection?.effectiveType || "unknown";
  logToServer({ type: "network_status", status: conn });
}, 10000);




// === Background Task (simulated logging) ===
// setInterval(() => {
//   const conn = navigator.connection?.effectiveType || "unknown";
//   console.log(`[Background Log] Network status: ${conn}`);
// }, 10000); // every 10 seconds
