# 🚦 SafeCommute

SafeCommute is a web app that promotes road safety using visual traffic signs and tips. It uses modern Web APIs to simulate background network monitoring, draw safety signs on canvas, and reveal tips based on visibility.

---

## 🌐 Features

- Dynamic traffic signs with Canvas API
- Safety tips shown for each sign
- Intersection Observer API to animate tips on scroll
- Background network status monitoring with Network Information API

---

## 🛠️ Technologies Used

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Web APIs**:  
  - Canvas API  
  - Intersection Observer API  
  - Network Information API
---

## 🚀 How to Run
# 1
1. Clone or download the project folder.
2. Open `index.html` in a web browser.
3. Choose a sign from the dropdown and view the safety tips and canvas drawing.

# 2. (Optional) Create a virtual environment
1.python -m venv venv
2. source venv/bin/activate   # On Windows: 3. 3. 3.3. .venv\Scripts\activate

# 3. Install required dependencies
pip install flask
pip install datetime

# 4. Run the Flask server
python app.py

---
By default, the app runs at:
http://127.0.0.1:5000
