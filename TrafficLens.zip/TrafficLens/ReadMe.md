# 🚦 SafeCommute

SafeCommute is a web app that promotes road safety using visual traffic signs and tips. It uses modern Web APIs to simulate background network monitoring, draw safety signs on canvas, and reveal tips based on visibility.

---

## 🌐 Features

- Dynamic traffic signs with Canvas API
- Safety tips shown for each sign
- Intersection Observer API to animate tips on scroll
- Background network status monitoring with Network Information API

---

## 🛠️ Technologies Used

- HTML5, CSS3
- JavaScript (Vanilla)
- Canvas API
- Intersection Observer API
- Network Information API

---

## 🚀 How to Run

1. Clone or download the project folder.
2. Open `index.html` in a web browser.
3. Choose a sign from the dropdown and view the safety tips and canvas drawing.

---

