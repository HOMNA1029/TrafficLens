from flask import Flask, render_template, request, jsonify
import os, json
from datetime import datetime

app = Flask(__name__)

LOG_FILE = "logs/events.json"

# Ensure log directory exists
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/log", methods=["POST"])
def log_event():
    data = request.json
    data["timestamp"] = datetime().isoformat()
    
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w") as f:
            json.dump([], f)

    with open(LOG_FILE, "r+") as f:
        events = json.load(f)
        events.append(data)
        f.seek(0)
        json.dump(events, f, indent=2)

    return jsonify({"status": "logged"}), 200

@app.route("/tips")
def get_tips():
    tips = {
        "stop": ["🛑 Always stop before crossing.", "👀 Look both ways.", "🚸 Ensure it's safe before moving."],
        "go": ["✅ Proceed only when it's green.", "🚶 Cross quickly and carefully.", "👣 Let others finish crossing first."],
        "caution": ["⚠️ Be alert near intersections.", "🚧 Watch for construction signs.", "👀 Make eye contact with drivers."]
    }
    return jsonify(tips)

if __name__ == "__main__":
    app.run(debug=True)

